"""
Smart Waste Segregation Game - Desktop Version with OpenCV
Integrated for ClimateGuardian AI

Controls:
- Show your hand to the camera
- Pinch (Index + Thumb) to grab trash items
- Drag to matching colored bin
- Release pinch to drop

Press SPACE to start, P to pause, Q to quit
"""

import cv2
import mediapipe as mp
import random
import math
import time
import numpy as np
import sys

# --- Configuration ---
WIDTH, HEIGHT = 800, 600
BIN_HEIGHT = 100
INITIAL_SPAWN_RATE = 2.0
INITIAL_FALL_SPEED = 3
PINCH_THRESHOLD = 50
MAX_MISSED = 5

# Colors (BGR format for OpenCV)
BLUE = (255, 100, 50)
YELLOW = (0, 215, 255)
RED = (50, 50, 255)
GREEN = (50, 200, 50)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)

# Trash Types Configuration
TRASH_TYPES = {
    'plastic': {'color': BLUE, 'label': 'PLASTIC', 'bin_x': 0, 'icon': '🧴'},
    'paper': {'color': YELLOW, 'label': 'PAPER', 'bin_x': 1, 'icon': '📄'},
    'metal': {'color': RED, 'label': 'METAL', 'bin_x': 2, 'icon': '🥫'},
    'organic': {'color': GREEN, 'label': 'ORGANIC', 'bin_x': 3, 'icon': '🍎'}
}


class GameState:
    """Manages the overall game state."""
    
    def __init__(self):
        self.score = 0
        self.missed = 0
        self.level = 1
        self.falling_items = []
        self.last_spawn_time = time.time()
        self.spawn_rate = INITIAL_SPAWN_RATE
        self.fall_speed = INITIAL_FALL_SPEED
        self.game_over = False
        self.paused = False
        self.show_start_screen = True
        self.hand_detected = False
        
    def reset(self):
        """Reset game to initial state."""
        self.score = 0
        self.missed = 0
        self.level = 1
        self.falling_items = []
        self.last_spawn_time = time.time()
        self.spawn_rate = INITIAL_SPAWN_RATE
        self.fall_speed = INITIAL_FALL_SPEED
        self.game_over = False
        self.paused = False
        self.show_start_screen = True


class TrashItem:
    """Represents a falling trash item."""
    
    def __init__(self):
        self.type_key = random.choice(list(TRASH_TYPES.keys()))
        self.data = TRASH_TYPES[self.type_key]
        self.size = 50
        self.x = random.randint(50, WIDTH - 100)
        self.y = -self.size
        self.is_dragging = False
        self.vx = 0
        self.vy = INITIAL_FALL_SPEED
    
    def update(self, hand_pos=None, is_pinching=False, current_fall_speed=3):
        """Update item position."""
        if self.is_dragging and hand_pos:
            self.x = hand_pos[0] - self.size // 2
            self.y = hand_pos[1] - self.size // 2
            self.x = max(0, min(self.x, WIDTH - self.size))
            self.y = max(0, min(self.y, HEIGHT - self.size))
        else:
            self.vy = current_fall_speed
            self.y += self.vy


class HandTracker:
    """Handles MediaPipe hand tracking."""
    
    def __init__(self):
        self.mp_hands = mp.solutions.hands
        self.mp_drawing = mp.solutions.drawing_utils
        self.hands = self.mp_hands.Hands(
            max_num_hands=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        
    def process_frame(self, frame):
        """Process a frame and return hand tracking results."""
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb_frame)
        return results
    
    def get_hand_info(self, results, frame):
        """Extract hand information from detection results."""
        h, w, _ = frame.shape
        cursor_pos = None
        is_pinching = False
        pinch_distance = 0
        
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                idx_tip = hand_landmarks.landmark[8]
                thm_tip = hand_landmarks.landmark[4]
                
                ix, iy = int(idx_tip.x * w), int(idx_tip.y * h)
                tx, ty = int(thm_tip.x * w), int(thm_tip.y * h)
                
                cursor_pos = ((ix + tx) // 2, (iy + ty) // 2)
                pinch_distance = math.hypot(ix - tx, iy - ty)
                is_pinching = pinch_distance < PINCH_THRESHOLD
                
                return cursor_pos, is_pinching, pinch_distance
        
        return cursor_pos, is_pinching, pinch_distance


def draw_bins(frame):
    """Draw the colored bins at the bottom."""
    bin_w = WIDTH // 4
    
    for key, data in TRASH_TYPES.items():
        idx = data['bin_x']
        x = idx * bin_w
        y = HEIGHT - BIN_HEIGHT
        
        cv2.rectangle(frame, (x, y), (x + bin_w, HEIGHT), data['color'], -1)
        cv2.rectangle(frame, (x, y), (x + bin_w, HEIGHT), WHITE, 3)
        
        text_size = cv2.getTextSize(data['label'], cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)[0]
        text_x = x + (bin_w - text_size[0]) // 2
        cv2.putText(frame, data['label'], (text_x, y + 35), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, WHITE, 2)
        
        cv2.putText(frame, "▼", (x + bin_w//2 - 10, y + 75), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, WHITE, 2)


def draw_trash_item(frame, item):
    """Draw a trash item."""
    x, y = int(item.x), int(item.y)
    size = item.size
    color = item.data['color']
    
    cv2.rectangle(frame, (x, y), (x + size, y + size), color, -1)
    cv2.rectangle(frame, (x, y), (x + size, y + size), WHITE, 3)
    
    center_x, center_y = x + size//2, y + size//2
    cv2.circle(frame, (center_x, center_y), size//2 - 5, WHITE, -1)
    cv2.putText(frame, item.data['label'][0], (center_x - 10, center_y + 10), 
                cv2.FONT_HERSHEY_SIMPLEX, 1, BLACK, 2)


def draw_hand_indicator(frame, cursor_pos, is_pinching):
    """Draw hand cursor indicator."""
    if cursor_pos:
        cx, cy = cursor_pos
        
        if is_pinching:
            cv2.circle(frame, (cx, cy), 25, (50, 255, 50), -1)
            cv2.circle(frame, (cx, cy), 25, WHITE, 3)
            cv2.putText(frame, "GRAB", (cx - 25, cy - 35), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50, 255, 50), 2)
        else:
            cv2.circle(frame, (cx, cy), 15, (50, 50, 255), -1)
            cv2.circle(frame, (cx, cy), 15, WHITE, 2)


def check_bin_drop(item):
    """Check if item was dropped in a bin."""
    bin_w = WIDTH // 4
    center_x = item.x + item.size // 2
    center_y = item.y + item.size // 2
    
    if center_y > HEIGHT - BIN_HEIGHT:
        col = int(center_x // bin_w)
        
        target_type = None
        for key, data in TRASH_TYPES.items():
            if data['bin_x'] == col:
                target_type = key
                break
        
        if target_type:
            return True, target_type
    
    return False, None


def draw_score_panel(frame, game_state):
    """Draw the score panel at the top."""
    cv2.rectangle(frame, (10, 10), (250, 100), (255, 255, 255), -1)
    cv2.rectangle(frame, (10, 10), (250, 100), GRAY, 2)
    
    cv2.putText(frame, f"Score: {game_state.score}", (25, 40), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, BLACK, 2)
    
    missed_color = (50, 50, 255) if game_state.missed >= 3 else BLACK
    cv2.putText(frame, f"Missed: {game_state.missed}/{MAX_MISSED}", (25, 65), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, missed_color, 2)
    
    cv2.putText(frame, f"Level: {game_state.level}", (25, 90), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, BLACK, 2)


def draw_start_screen(frame):
    """Draw the start screen overlay."""
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (WIDTH, HEIGHT), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
    
    title_box_x = WIDTH // 2 - 250
    title_box_y = HEIGHT // 2 - 150
    cv2.rectangle(frame, (title_box_x, title_box_y), 
                  (title_box_x + 500, title_box_y + 300), (34, 139, 34), -1)
    cv2.rectangle(frame, (title_box_x, title_box_y), 
                  (title_box_x + 500, title_box_y + 300), WHITE, 3)
    
    cv2.putText(frame, "SMART WASTE", WIDTH//2 - 130, title_box_y + 60,
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, WHITE, 3)
    cv2.putText(frame, "SEGREGATION", WIDTH//2 - 125, title_box_y + 100,
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, WHITE, 3)
    
    instructions = [
        "Show your hand to camera",
        "Pinch to grab trash",
        "Drag to matching bin",
        "Release to drop",
        "",
        "Press SPACE to Start",
        "Press P to Pause",
        "Press Q to Quit"
    ]
    
    for i, instr in enumerate(instructions):
        color = (144, 238, 144) if i < 5 else WHITE
        cv2.putText(frame, instr, WIDTH//2 - 150, title_box_y + 150 + i*22,
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 1)


def draw_game_over(frame, game_state):
    """Draw the game over screen."""
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (WIDTH, HEIGHT), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.8, frame, 0.2, 0, frame)
    
    box_x = WIDTH // 2 - 200
    box_y = HEIGHT // 2 - 120
    cv2.rectangle(frame, (box_x, box_y), (box_x + 400, box_y + 240), (50, 50, 50), -1)
    cv2.rectangle(frame, (box_x, box_y), (box_x + 400, box_y + 240), (50, 50, 255), 3)
    
    cv2.putText(frame, "GAME OVER", WIDTH//2 - 100, box_y + 50,
                cv2.FONT_HERSHEY_SIMPLEX, 1.8, (50, 50, 255), 3)
    
    cv2.putText(frame, f"Final Score: {game_state.score}", WIDTH//2 - 90, box_y + 100,
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, WHITE, 2)
    
    cv2.putText(frame, f"Level Reached: {game_state.level}", WIDTH//2 - 110, box_y + 140,
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (144, 238, 144), 2)
    
    cv2.putText(frame, "Press R to Restart | Q to Quit", WIDTH//2 - 150, box_y + 190,
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, WHITE, 1)


def draw_paused_screen(frame):
    """Draw the paused screen."""
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (WIDTH, HEIGHT), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
    
    cv2.putText(frame, "PAUSED", WIDTH//2 - 60, HEIGHT//2,
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, WHITE, 2)
    cv2.putText(frame, "Press P to Resume", WIDTH//2 - 80, HEIGHT//2 + 40,
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, WHITE, 1)


def run_game():
    """Main game function."""
    print("🎮 Starting Smart Waste Segregation Game...")
    
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("❌ ERROR: Could not open camera!")
        return 0
    
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
    
    hand_tracker = HandTracker()
    game_state = GameState()
    
    print("✅ Game ready! Press SPACE to start!")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        frame = cv2.flip(frame, 1)
        
        results = hand_tracker.process_frame(frame)
        cursor_pos, is_pinching, _ = hand_tracker.get_hand_info(results, frame)
        game_state.hand_detected = cursor_pos is not None
        
        draw_bins(frame)
        
        if not game_state.show_start_screen and not game_state.game_over:
            if not game_state.paused and time.time() - game_state.last_spawn_time > game_state.spawn_rate:
                game_state.falling_items.append(TrashItem())
                game_state.last_spawn_time = time.time()
            
            items_to_remove = []
            
            for item in game_state.falling_items:
                if is_pinching and cursor_pos and not item.is_dragging:
                    item_center_x = item.x + item.size // 2
                    item_center_y = item.y + item.size // 2
                    dist = math.hypot(cursor_pos[0] - item_center_x, 
                                     cursor_pos[1] - item_center_y)
                    
                    if dist < 60:
                        if not any(i.is_dragging for i in game_state.falling_items if i != item):
                            item.is_dragging = True
                
                item.update(cursor_pos, is_pinching, game_state.fall_speed)
                draw_trash_item(frame, item)
                
                if not is_pinching and item.is_dragging:
                    dropped, target_type = check_bin_drop(item)
                    
                    if dropped:
                        if target_type == item.type_key:
                            game_state.score += 10
                            new_level = game_state.score // 50 + 1
                            if new_level > game_state.level:
                                game_state.level = new_level
                                game_state.spawn_rate = max(0.8, INITIAL_SPAWN_RATE - (new_level - 1) * 0.15)
                                game_state.fall_speed = min(7, INITIAL_FALL_SPEED + (new_level - 1) * 0.3)
                        else:
                            game_state.score = max(0, game_state.score - 5)
                        
                        items_to_remove.append(item)
                    else:
                        item.is_dragging = False
                
                if item.y > HEIGHT and item not in items_to_remove:
                    items_to_remove.append(item)
                    game_state.missed += 1
                    
                    if game_state.missed >= MAX_MISSED:
                        game_state.game_over = True
            
            for item in items_to_remove:
                if item in game_state.falling_items:
                    game_state.falling_items.remove(item)
            
            draw_hand_indicator(frame, cursor_pos, is_pinching)
            draw_score_panel(frame, game_state)
            
            if game_state.paused:
                draw_paused_screen(frame)
        
        elif game_state.show_start_screen:
            draw_start_screen(frame)
        
        elif game_state.game_over:
            for item in game_state.falling_items:
                draw_trash_item(frame, item)
            draw_game_over(frame, game_state)
        
        cv2.imshow('Smart Waste Segregation', frame)
        
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord('q') or key == ord('Q'):
            print("\n👋 Thanks for playing!")
            break
        
        elif key == ord(' ') and game_state.show_start_screen:
            game_state.show_start_screen = False
            print("\n🎮 Game Started!")
        
        elif key == ord('p') or key == ord('P'):
            if not game_state.show_start_screen and not game_state.game_over:
                game_state.paused = not game_state.paused
        
        elif key == ord('r') or key == ord('R'):
            if game_state.game_over or game_state.show_start_screen:
                game_state.reset()
                print("\n🔄 Game Restarted!")
    
    cap.release()
    cv2.destroyAllWindows()
    print(f"\n🏆 Final Score: {game_state.score}")
    return game_state.score


if __name__ == "__main__":
    try:
        run_game()
    except KeyboardInterrupt:
        print("\n\n⚠️ Game interrupted.")
    except Exception as e:
        print(f"\n❌ Error: {e}")
    finally:
        print("\n👋 Goodbye!")
