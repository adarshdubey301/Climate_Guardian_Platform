/* ==========================================
   AI QUIZ GENERATOR
   ========================================== */

let selectedOption = -1;

function generateQuiz() {
    const questions = [
        {
            q: "What do the 3Rs stand for in environmental conservation?",
            options: ["Run, Read, Rest", "Reduce, Reuse, Recycle", "Rise, Ride, Race", "Red, Redder, Reddest"],
            ans: 1,
            exp: "The 3Rs help minimize waste and protect the environment!"
        },
        {
            q: "Which renewable energy source uses sunlight?",
            options: ["Wind Power", "Solar Power", "Hydroelectric", "Geothermal"],
            ans: 1,
            exp: "Solar panels convert sunlight into clean electricity!"
        },
        {
            q: "What gas do trees absorb from the atmosphere?",
            options: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"],
            ans: 2,
            exp: "Trees absorb CO₂ and release oxygen through photosynthesis!"
        },
        {
            q: "How long does a plastic bottle take to decompose?",
            options: ["1 year", "10 years", "100 years", "450 years"],
            ans: 3,
            exp: "Plastic pollution is a major environmental issue - always recycle!"
        },
        {
            q: "Which transportation method has the lowest carbon footprint?",
            options: ["Car", "Bus", "Bicycle", "Airplane"],
            ans: 2,
            exp: "Bicycling produces zero emissions and promotes health!"
        },
        {
            q: "What percentage of Earth's water is freshwater?",
            options: ["3%", "25%", "50%", "75%"],
            ans: 0,
            exp: "Only 3% of Earth's water is fresh, and most of it is frozen in ice caps!"
        },
        {
            q: "Which of these materials is NOT recyclable?",
            options: ["Aluminum cans", "Glass bottles", "Styrofoam", "Paper"],
            ans: 2,
            exp: "Styrofoam is difficult to recycle and harms the environment!"
        },
        {
            q: "What is the main cause of climate change?",
            options: ["Volcanic eruptions", "Greenhouse gases", "Ocean currents", "Solar activity"],
            ans: 1,
            exp: "Human-produced greenhouse gases are the primary driver of climate change!"
        }
    ];

    currentQuiz = questions[Math.floor(Math.random() * questions.length)];
    
    let html = `
        <h4 class="text-xl font-bold mb-4">${currentQuiz.q}</h4>
        <div class="space-y-3">
    `;

    currentQuiz.options.forEach((opt, idx) => {
        html += `
            <div class="quiz-option" onclick="selectOption(${idx})">
                ${String.fromCharCode(65 + idx)}. ${opt}
            </div>
        `;
    });

    html += `
        </div>
        <button onclick="submitQuiz()" class="btn-primary mt-6">Submit Answer</button>
    `;

    document.getElementById('quizContent').innerHTML = html;
}

function selectOption(idx) {
    selectedOption = idx;
    document.querySelectorAll('.quiz-option').forEach((opt, i) => {
        opt.classList.toggle('selected', i === idx);
    });
}

function submitQuiz() {
    if (selectedOption === -1) {
        alert('Please select an answer!');
        return;
    }

    if (selectedOption === currentQuiz.ans) {
        ecoScore += 15;
        document.getElementById('ecoScore').textContent = ecoScore;
        logActivity('AI Quiz Win', 15);
        
        alert('🎉 Correct! ' + currentQuiz.exp);
        setTimeout(() => {
            document.getElementById('quizContent').innerHTML = `
                <div class="text-center py-12">
                    <img src="https://cdn-icons-png.flaticon.com/512/4148/4148323.png" class="w-32 h-32 mx-auto mb-6">
                    <button onclick="generateQuiz()" class="game-button">🌱 Generate New Question</button>
                </div>
            `;
        }, 2000);
    } else {
        alert('❌ Oops! The correct answer was: ' + currentQuiz.options[currentQuiz.ans] + '\n\n' + currentQuiz.exp);
        setTimeout(() => {
            document.getElementById('quizContent').innerHTML = `
                <div class="text-center py-12">
                    <img src="https://cdn-icons-png.flaticon.com/512/4148/4148323.png" class="w-32 h-32 mx-auto mb-6">
                    <button onclick="generateQuiz()" class="game-button">🌱 Generate New Question</button>
                </div>
            `;
        }, 3000);
    }
    selectedOption = -1;
}
