import streamlit as st
import pandas as pd
import plotly.express as px
import datetime
import time
import google.generativeai as genai
from PIL import Image
import os
import random
import auth  # Import authentication module

# ==========================================
# 0. CONFIGURATION & STYLING
# ==========================================
st.set_page_config(page_title="ClimateGuardian AI", page_icon="🌿", layout="wide", initial_sidebar_state="collapsed")

# Configure the API key
# Note: In production, store this in secrets.toml
genai.configure(api_key=st.secrets.get("GEMINI_API_KEY", "YOUR_API_KEY_HERE"))

# --- CUSTOM CSS FOR ECO THEME ---
st.markdown("""
    <style>
    /* Main Background */
    .stApp {
        background: linear-gradient(135deg, #f4fdf4 0%, #e8f5e9 100%);
    }
    
    /* Sidebar Styling */
    section[data-testid="stSidebar"] {
        background-color: #e8f5e9;
        border-right: 3px solid #c8e6c9;
    }
    
    /* Headers */
    h1, h2, h3 {
        color: #2e7d32;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    /* Buttons */
    div.stButton > button {
        background-color: #4CAF50;
        color: white;
        border-radius: 12px;
        border: none;
        padding: 10px 24px;
        font-weight: bold;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        transition: 0.3s;
    }
    div.stButton > button:hover {
        background-color: #45a049;
        transform: scale(1.05);
    }
    
    /* Input Fields */
    .stTextInput > div > div > input {
        border-radius: 10px;
        border: 2px solid #4CAF50;
    }
    
    /* Metrics */
    div[data-testid="stMetricValue"] {
        color: #1b5e20;
        font-size: 2em;
        font-weight: bold;
    }
    
    /* Custom Card */
    .eco-card {
        padding: 25px;
        background-color: white;
        border-radius: 15px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        margin-bottom: 20px;
        border-left: 5px solid #4CAF50;
    }
    
    /* Game Card */
    .game-card {
        padding: 30px;
        background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
        border-radius: 20px;
        box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        margin-bottom: 25px;
        border: 3px solid #4CAF50;
        text-align: center;
    }
    
    /* Progress Bar Custom */
    .progress-container {
        background-color: #e0e0e0;
        border-radius: 20px;
        padding: 3px;
        margin: 10px 0;
    }
    
    .progress-bar {
        background: linear-gradient(90deg, #4CAF50 0%, #8BC34A 100%);
        height: 25px;
        border-radius: 20px;
        text-align: center;
        color: white;
        font-weight: bold;
        line-height: 25px;
    }
    
    /* Chat Messages */
    .chat-message {
        padding: 10px 15px;
        border-radius: 10px;
        margin: 10px 0;
    }
    
    .user-message {
        background-color: #4CAF50;
        color: white;
        margin-left: 20%;
    }
    
    .assistant-message {
        background-color: #f0f0f0;
        color: #333;
        margin-right: 20%;
    }
    </style>
    """, unsafe_allow_html=True)

# ==========================================
# 1. SESSION STATE SETUP
# ==========================================
if 'student_data' not in st.session_state:
    st.session_state['student_data'] = pd.DataFrame(columns=['Student_ID', 'Action', 'Points', 'Date'])

if 'messages' not in st.session_state:
    st.session_state['messages'] = [{"role": "assistant", "content": "🌿 Hi! I'm EcoBot. I can generate quizzes, give tips, or help you save the planet!"}]

if 'quiz_data' not in st.session_state:
    st.session_state['quiz_data'] = None

# Game-specific session states
if 'carbon_footprint' not in st.session_state:
    st.session_state['carbon_footprint'] = 100
    
if 'eco_score' not in st.session_state:
    st.session_state['eco_score'] = 0

# ==========================================
# 2. HELPER FUNCTIONS
# ==========================================

def get_gemini_model():
    """Get Gemini AI model instance"""
    return genai.GenerativeModel('gemini-pro')

def generate_ai_quiz_question():
    """Generates a dynamic quiz question using Gemini"""
    try:
        model = get_gemini_model()
        prompt = """
        Generate 1 multiple choice question about environmental sustainability, recycling, or climate change.
        Strictly follow this format using the pipe symbol (|) as a separator:
        Question Text | Option A | Option B | Option C | Option D | Correct Option (A/B/C/D) | Short Explanation
        
        Example:
        What is the 3R rule? | Run, Read, Rest | Reduce, Reuse, Recycle | Rise, Ride, Race | Red, Redder, Reddest | B | The 3Rs help cut down on waste.
        """
        response = model.generate_content(prompt)
        text = response.text.strip()
        parts = text.split('|')
        
        if len(parts) >= 6:
            return {
                "q": parts[0].strip(),
                "options": [parts[1].strip(), parts[2].strip(), parts[3].strip(), parts[4].strip()],
                "ans": parts[5].strip().upper(),
                "exp": parts[6].strip() if len(parts) > 6 else "Great job saving the planet!"
            }
        else:
            return None
    except Exception as e:
        st.error(f"Error generating quiz: {str(e)}")
        return None

def log_action(action, points):
    """Log student action to database"""
    new_data = pd.DataFrame({
        'Student_ID': ['Student_User'], 
        'Action': [action],
        'Points': [points],
        'Date': [datetime.date.today()]
    })
    st.session_state['student_data'] = pd.concat([st.session_state['student_data'], new_data], ignore_index=True)
    st.session_state['eco_score'] += points

# ==========================================
# 3. AI CHAT INTERFACE
# ==========================================

def chat_interface():
    st.markdown('<div class="eco-card"><h3>🤖 EcoBot Mentor</h3><p>Ask me anything about nature and sustainability!</p></div>', unsafe_allow_html=True)
    
    # Display chat messages
    for msg in st.session_state.messages:
        if msg["role"] == "user":
            st.markdown(f'<div class="chat-message user-message">{msg["content"]}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="chat-message assistant-message">🌿 {msg["content"]}</div>', unsafe_allow_html=True)

    # Chat input
    if prompt := st.chat_input("How can I recycle glass?"):
        st.session_state.messages.append({"role": "user", "content": prompt})

        with st.spinner("EcoBot is thinking... 🌱"):
            try:
                model = get_gemini_model()
                ai_prompt = f"You are EcoBot, a fun sustainability expert for students. Keep it short (2-3 sentences) and encouraging. Answer: {prompt}"
                response = model.generate_content(ai_prompt)
                reply = response.text
            except Exception as e:
                reply = "I'm having trouble connecting to the nature network. Try again! 🌍"
        
        st.session_state.messages.append({"role": "assistant", "content": reply})
        st.rerun()

# ==========================================
# 4. AI QUIZ GAME
# ==========================================

def quiz_interface():
    st.markdown('<div class="eco-card"><h3>🎮 AI Eco-Challenge</h3><p>Infinite questions generated by AI!</p></div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        if st.session_state['quiz_data'] is None:
            if st.button("🌱 Generate New Question", key="gen_quiz"):
                with st.spinner("Growing a new question..."):
                    q_data = generate_ai_quiz_question()
                    if q_data:
                        st.session_state['quiz_data'] = q_data
                        st.rerun()
                    else:
                        st.error("AI couldn't generate a question. Try again.")
        
        if st.session_state['quiz_data']:
            q = st.session_state['quiz_data']
            st.subheader(f"Q: {q['q']}")
            
            opts = q['options']
            choice = st.radio("Select an answer:", opts, key="quiz_choice")
            
            choice_index = opts.index(choice)
            choice_letter = ["A", "B", "C", "D"][choice_index]
            
            if st.button("Submit Answer", key="submit_quiz"):
                if choice_letter == q['ans']:
                    st.balloons()
                    st.success(f"✅ Correct! 🎉 {q['exp']}")
                    log_action("AI Quiz Win", 15)
                    time.sleep(2)
                    st.session_state['quiz_data'] = None
                    st.rerun()
                else:
                    st.error(f"❌ Oops! The correct answer was Option {q['ans']}.")
                    st.warning(q['exp'])
                    time.sleep(3)
                    st.session_state['quiz_data'] = None
                    st.rerun()

    with col2:
        st.image("https://cdn-icons-png.flaticon.com/512/4148/4148323.png", width=150)
        st.metric("🌱 Eco-Score", st.session_state['eco_score'])

# ==========================================
# 5. MISSION TRACKER
# ==========================================

def mission_tracker():
    st.markdown('<div class="eco-card"><h3>📝 Daily Green Missions</h3></div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        action = st.selectbox("Select Mission Completed:", 
                              ["Recycled Plastic", "Planted a Tree", "Walked/Biked to School", 
                               "Saved Electricity", "Used Reusable Bag", "Composted Food"],
                              key="mission_select")
    
    with col2:
        points_map = {
            "Recycled Plastic": 5, 
            "Planted a Tree": 50, 
            "Walked/Biked to School": 20, 
            "Saved Electricity": 10, 
            "Used Reusable Bag": 5, 
            "Composted Food": 15
        }
        st.metric(label="Points Value", value=points_map[action])
    
    if st.button("✅ Log Mission", key="log_mission"):
        log_action(action, points_map[action])
        st.success(f"Mission '{action}' logged! +{points_map[action]} points")
        time.sleep(1)
        st.rerun()
    
    # Mission History
    st.markdown("### 📋 Mission History")
    df = st.session_state['student_data']
    if df.empty:
        st.info("No missions logged yet.")
    else:
        recent = df.tail(5).sort_index(ascending=False)
        st.dataframe(recent[['Action', 'Points', 'Date']], use_container_width=True)

# ==========================================
# 6. SUSTAINABILITY PREDICTOR
# ==========================================

def sustainability_predictor():
    st.markdown('<div class="eco-card"><h3>🔮 Predict Your Sustainability Impact</h3></div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("#### 🌍 Carbon Footprint Tracker")
        
        transport = st.selectbox("🚗 Transportation:", 
                                ["Walk/Bike (-5 CO₂)", "Public Transport (-2 CO₂)", 
                                 "Electric Car (0 CO₂)", "Gasoline Car (+10 CO₂)"],
                                key="transport")
        
        diet = st.selectbox("🍽️ Diet:", 
                           ["Plant-Based (-3 CO₂)", "Local Produce (-2 CO₂)", 
                            "Mixed Diet (+2 CO₂)", "Imported Meat (+8 CO₂)"],
                           key="diet")
        
        energy = st.selectbox("💡 Energy:", 
                             ["Solar Power (-5 CO₂)", "Energy Saver (-3 CO₂)", 
                              "Normal Usage (+1 CO₂)", "High Consumption (+7 CO₂)"],
                             key="energy")
        
        if st.button("📊 Calculate Impact", key="calc_impact"):
            # Extract values
            transport_val = int(transport.split('(')[1].split()[0].replace('+', ''))
            diet_val = int(diet.split('(')[1].split()[0].replace('+', ''))
            energy_val = int(energy.split('(')[1].split()[0].replace('+', ''))
            
            change = transport_val + diet_val + energy_val
            st.session_state['carbon_footprint'] += change
            st.session_state['carbon_footprint'] = max(0, min(200, st.session_state['carbon_footprint']))
            
            if change < 0:
                st.success(f"🎉 Amazing! You reduced carbon by {abs(change)} units!")
                log_action("Carbon Reduction", abs(change) * 2)
                st.balloons()
            else:
                st.warning(f"⚠️ Your choices increased carbon by {change} units.")
            
            time.sleep(1)
            st.rerun()
    
    with col2:
        carbon = st.session_state['carbon_footprint']
        st.metric("🌡️ Your Carbon Level", f"{carbon} CO₂")
        
        # Status
        if carbon <= 50:
            status = "🌟 Eco Hero!"
            color = "#4CAF50"
        elif carbon <= 100:
            status = "👍 Good Job!"
            color = "#FFC107"
        else:
            status = "🔥 Need Improvement"
            color = "#F44336"
        
        st.markdown(f"**Status:** {status}")
        
        # Progress bar
        percentage = min(100, (carbon / 200) * 100)
        progress_html = f"""
        <div class="progress-container">
            <div class="progress-bar" style="width: {percentage}%; background-color: {color};">
                {int(percentage)}%
            </div>
        </div>
        """
        st.markdown(progress_html, unsafe_allow_html=True)
        
        if st.button("🔄 Reset", key="reset_carbon"):
            st.session_state['carbon_footprint'] = 100
            st.rerun()

# ==========================================
# 7. GAMES HUB (PYGAME EMBEDDED)
# ==========================================

def games_hub():
    st.markdown('<div class="eco-card"><h2>🎯 Interactive Sustainability Games</h2><p>Play, Learn, and Save the Planet!</p></div>', unsafe_allow_html=True)
    
    # Three games in grid layout
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div class="game-card">
            <h3>🏃 Eco-Runner</h3>
            <img src="https://cdn-icons-png.flaticon.com/512/3588/3588435.png" width="120">
            <p style="margin: 15px 0;">Control a person collecting leaves while avoiding waste! Get your carbon score to zero!</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.info("🎮 **How to Play:**\n- Use ↑↓ arrow keys to move\n- Collect green leaves (-10 CO₂)\n- Avoid red waste (+20 CO₂)\n- Goal: Reach 0 carbon!")
        
        if st.button("🎮 Launch Eco-Runner", key="launch_eco_runner"):
            st.success("✅ Game launching! Check the pygame window that opened.")
            st.balloons()
            try:
                import games.eco_runner as eco_runner
                eco_runner.run_game()
                # After game ends, add points
                log_action("Eco-Runner Victory", 50)
                st.session_state['eco_score'] += 50
                st.success("🎉 Game completed! +50 points added!")
                time.sleep(2)
                st.rerun()
            except Exception as e:
                st.error(f"Error launching game: {str(e)}")
    
    with col2:
        st.markdown("""
        <div class="game-card">
            <h3>⚡ Renewable Energy Puzzle</h3>
            <img src="https://cdn-icons-png.flaticon.com/512/3176/3176215.png" width="120">
            <p style="margin: 15px 0;">Match renewable energy sources to the right locations and achieve net-zero emissions!</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.info("🎮 **How to Play:**\n- Click energy button (Solar/Wind/Hydro)\n- Click matching colored tiles\n- Correct = -50 emissions\n- Wrong = +30 emissions\n- Goal: Reach net-zero!")
        
        if st.button("🎮 Launch Renewable Energy Puzzle", key="launch_renewable"):
            st.success("✅ Game launching! Check the pygame window that opened.")
            st.balloons()
            try:
                import games.renewable_energy as renewable_energy
                renewable_energy.run_game()
                # After game ends, add points
                log_action("Renewable Energy Victory", 50)
                st.session_state['eco_score'] += 50
                st.success("🎉 Game completed! +50 points added!")
                time.sleep(2)
                st.rerun()
            except Exception as e:
                st.error(f"Error launching game: {str(e)}")
    
    with col3:
        st.markdown("""
        <div class="game-card">
            <h3>♻️ Smart Waste Segregation</h3>
            <img src="https://cdn-icons-png.flaticon.com/512/3524/3524388.png" width="120">
            <p style="margin: 15px 0;">Use hand gestures to sort waste into correct bins! AI-powered recycling game!</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.info("🎮 **How to Play:**\n- Allow camera access\n- Use hand pinch to grab items\n- Sort into correct colored bins\n- Goal: High score before 5 misses!")
        
        if st.button("🎮 Launch Waste Segregation", key="launch_waste_seg"):
            # Import and run the game inline
            import games.waste_segregation as waste_segregation
            waste_segregation.run_game()

# ==========================================
# 8. ADMIN DASHBOARD
# ==========================================

def admin_dashboard():
    st.markdown('<div class="eco-card"><h3>🏫 School Sustainability Dashboard</h3></div>', unsafe_allow_html=True)
    
    df = st.session_state['student_data']
    
    if df.empty:
        st.info("📊 No data yet. Start logging missions and playing games!")
        return

    # Metrics
    col1, col2, col3 = st.columns(3)
    col1.metric("🌱 Total Eco-Points", df['Points'].sum())
    col2.metric("📊 Total Actions", len(df))
    col3.metric("🌳 Trees Planted", len(df[df['Action'] == "Planted a Tree"]))
    
    st.divider()
    
    # Charts
    chart_col1, chart_col2 = st.columns(2)
    
    with chart_col1:
        fig_pie = px.pie(df, names='Action', values='Points', 
                        title="Impact Distribution", 
                        color_discrete_sequence=px.colors.sequential.Greens_r)
        st.plotly_chart(fig_pie, use_container_width=True)
    
    with chart_col2:
        action_summary = df.groupby('Action')['Points'].sum().reset_index()
        fig_bar = px.bar(action_summary, x='Action', y='Points', 
                        title="Top Activities",
                        color='Points',
                        color_continuous_scale='Greens')
        st.plotly_chart(fig_bar, use_container_width=True)
    
    # Activity Log
    st.markdown("### 📈 Activity Log")
    st.dataframe(df.sort_index(ascending=False), use_container_width=True)

# ==========================================
# 9. MAIN LAYOUT
# ==========================================

def main():
    # Check if user is logged in
    if not st.session_state['logged_in']:
        # Show login or signup page
        if st.session_state.get('show_signup', False):
            auth.signup_page()
        else:
            auth.login_page()
        return
    
    # User is logged in - show main app
    # Sidebar
    with st.sidebar:
        st.title("🌍 ClimateGuardian AI")
        
        try:
            st.image("https://cdn-icons-png.flaticon.com/512/3773/3773698.png", width=150)
        except:
            pass
        
        st.markdown("**Save Earth, Save Future** 🌿")
        
        # User Profile Section
        st.markdown("---")
        st.markdown(f"### 👤 Welcome, {st.session_state['username']}!")
        
        user_info = st.session_state.get('user_info', {})
        if user_info:
            st.metric("🌱 Total Eco-Score", user_info.get('eco_score', 0))
        
        st.markdown("---")
        
        menu = st.radio("📍 Navigate", ["🎓 Student Hub", "📊 Admin Dashboard"])
        
        st.divider()
        st.info("💡 **Tip:** Complete missions daily to earn Eco-Points!")
        
        # Logout button
        if st.button("🚪 Logout", key="logout_btn", use_container_width=True):
            # Update user score before logout
            if st.session_state['username']:
                auth.update_user_score(st.session_state['username'], st.session_state['eco_score'])
            auth.logout()
        
        st.caption("Developed by Environment Cleaner")

    # Header
    st.title(f"🌿 Welcome to ClimateGuardian AI, {st.session_state['username']}!")
    st.markdown("*Your AI-powered companion for a greener planet*")
    st.divider()

    # Main Content
    if menu == "🎓 Student Hub":
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "🤖 AI Chat", 
            "🎮 AI Quiz", 
            "✅ Missions", 
            "🔮 Predict Sustainability",
            "🎯 Games Hub"
        ])
        
        with tab1:
            chat_interface()
        with tab2:
            quiz_interface()
        with tab3:
            mission_tracker()
        with tab4:
            sustainability_predictor()
        with tab5:
            games_hub()
            
    elif menu == "📊 Admin Dashboard":
        admin_dashboard()

if __name__ == "__main__":
    main()
